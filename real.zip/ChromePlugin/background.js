// 页面完全加载完成所耗时间----最重要!!!

console.log('background...');
