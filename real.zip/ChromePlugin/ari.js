// 页面完全加载完成所耗时间----最重要!!!
let mytiming = window.performance.timing;
let result = mytiming.responseStart - mytiming.navigationStart;
console.log('ari:', result);
return result;